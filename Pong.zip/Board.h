#ifndef  BOARD_H
#define BOARD_H

using namespace std;
#include <iostream>
#include <string.h>
#include "utils.h"
#include "Point.h"
#include <string>
#include "Ball.h"

#define _CRT_SECURE_NO_WARNINGS

class Board {
public:
	enum class ball_position { CENTER_HIT, CORNER_HIT, AWAY, MISSED,AFTER_BOARD };
	enum { MIN_X = 1, MAX_X = 79, MIN_Y = 3, MAX_Y = 23 };
	enum { UP ,DOWN,NUM_OF_CHARS_TO_USE};
private:
	int board_location;
	Point top_point, bottom_point;



protected:
	void draw(int coord_X, int coord_y, char ch) const
	{
		gotoxy(coord_X, coord_y);
		cout << ch;
	}

	void move_up()
	{
		top_point.set_y(top_point.get_y() - 1);
		bottom_point.set_y(bottom_point.get_y() - 1);
	}

	void move_down()
	{
		top_point.set_y(top_point.get_y() + 1);
		bottom_point.set_y(bottom_point.get_y() + 1);
	}
public:
	
	Board(int Top_y, int Bottom_y, int Board_location) :
		top_point(Board_location,Top_y, '|'), bottom_point(Board_location, Bottom_y, '|'), board_location(Board_location){}
	
	virtual ~Board() {}

	void initialize_drawer() const
	{
		draw(bottom_point.get_x(), bottom_point.get_y() , bottom_point.get_char());
		draw(bottom_point.get_x(), bottom_point.get_y() - 1, bottom_point.get_char());
		draw(top_point.get_x(), top_point.get_y(), top_point.get_char());
	}
	void board_eraser() const
	{
		draw(bottom_point.get_x(), bottom_point.get_y(), ' ');
		draw(bottom_point.get_x(), bottom_point.get_y() - 1,' ');
		draw(top_point.get_x(), top_point.get_y(), ' ');
	}

	int get_middle_y_coord()
	{
		return get_bottom_y_coord()-1;
	}
	
	virtual void move() {}


	/* checks if the ball will hit the board or not*/
	ball_position check_ball_position(const Ball& ball_to_check, const Point& point_to_check, int flag) const;

	int get_x_coord() const
	{
		return this->bottom_point.get_x();
	}
	void update_location(int x_change)
	{
		board_location += x_change;
		top_point.set_x(board_location);
		bottom_point.set_x(board_location);
	}

	int get_top_y_coord()
	{
		return top_point.get_y();
	}

	int get_bottom_y_coord()
	{
		return bottom_point.get_y();
	}

	void set_x_coord(int x)
	{
		top_point.set_x(x);
		bottom_point.set_x(x);
	}

	void set_bottom_point_y(int y_coord)
	{
		bottom_point.set_y(y_coord);
	}

	void set_top_point_y(int y_coord)
	{
		top_point.set_y(y_coord);
	}

};


#endif // ! BOARD_H