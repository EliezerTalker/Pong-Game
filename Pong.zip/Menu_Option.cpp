#include "Menu_Option.h"


Menu_Option::Menu_Option(const char* message, int Strarter_x, int Strarter_y)  
{
	message_size = strlen(message);
	Option_Message = new char[message_size + 1];

	for (int i = 0; i <= message_size; i++)
	{
		Option_Message[i] = message[i];     /* copys the message it got */
	}

	this->Starter_x = Strarter_x;
	this->Starter_y = Strarter_y;
	this->Ender_x = this->Starter_x + message_size - 1;
	this->Ender_y = Strarter_y;
}



void  Menu_Option::Set_starting_point(int coord_x, int coord_y)     /* sets the coords of the message*/
{
	this->Starter_x = coord_x;
	this->Starter_y = coord_y;
	this->Ender_x = this->Starter_x + message_size - 1;
	this->Ender_y = coord_y;
}

void Menu_Option::messages_print_deleter()
{
	if (am_i_printed == PRINTED)
	{
		int temp = Starter_x;
		while (Starter_x <= Ender_x)
		{
			gotoxy(Starter_x, Starter_y);
			cout << " ";
			Starter_x++;
		}
		Starter_x = temp;
		am_i_printed = NOT_PRINTED;

	}
}

void Menu_Option::message_setter(const char* message)   /* sets a wanted message*/
{
	int len = strlen(message);
	message_size = len;
	Option_Message = new char[len + 1];
	for (int i = 0; i <= len; i++)
	{
		Option_Message[i] = message[i];
	}
}