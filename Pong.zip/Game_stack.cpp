#include "Game_stack.h"

void Game_stack::push(game_objects * item)
{
	item->next=top;
	top = item; 

}

void Game_stack::pop()
{
	if (top != nullptr)
	{
		game_objects* temp;
		temp = top ->next;
		delete top;
		top = temp;
		
	}
}
