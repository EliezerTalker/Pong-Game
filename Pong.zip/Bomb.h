#ifndef  BOMB_H
#define BOMB_H
#include "Ball_Interface.h"

class Bomb : public Ball_Interface
{
	 /* this member tells us if the bomb is between the to boards*/
	bool in_range = false;;
	
public:


	Bomb()
	{

		set_ball_color(Ball_Interface::Ecolor::RED);

	}

	void counter_successor() override
	{
		in_range = (get_x_ball_coord() < get_right_limit()- 2 && get_x_ball_coord() > get_left_limit() + 1);
		    /* here we check if we are in bomb state and if the ball is between the boards (+3 because we take the right corner of the ball*/
		if (Ball_Interface::get_activation() && in_range)
		{
			Ball_Interface::counter_successor();

		}

	 }


	Ball_Interface::Eball_state get_next_ball_state()
	{

		if (get_activation() && get_counter() == 4)
		{
			set_activation(false);
			set_counter(0);
			return Ball_Interface::Eball_state::REGULAR;
		}

		else if (get_activation())  /* the only possible mods when in bomb state is bomb or regular */
		{
			return Ball_Interface::Eball_state::BOMB;
		}
	}








};


#endif // ! BOMB_H
