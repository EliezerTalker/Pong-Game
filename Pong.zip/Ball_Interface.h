
#ifndef  BALL_INTERFACE_H
#define  BALL_INTERFACE_H

#include "utils.h"
#include "Point.h"

class Ball_Interface
{
public:
	enum  class Ecolor { WHITE = 15, LIGHT_MAGENTA = 13, RED = 4 };
	enum class Eball_state { REGULAR, GOING_TO_BE_A_BOMB, BOMB };
private:
	Ecolor color;
	int counter=0;
    int left_limit;
    int right_limit;
 	int x_ball_coord;
	bool am_I_activated = false;
public:
	
	//virtual void if_missed() = 0;
	//virtual bool check_count(int count) = 0;
	virtual Ball_Interface::Eball_state get_next_ball_state() = 0;
	void print_in_color()
	{
		set_text_color((int)color);
	}

	virtual ~Ball_Interface() {}

	void set_ball_color(Ecolor wanted_color)
	{
		color = wanted_color;
	}

	virtual void counter_successor()
	{
		counter++;
	}
	int get_counter() const
	{
		return counter;
	}

	
	void set_counter(int value)
	{
		counter = value;
	}

	void set_left_limit(int left_lim)
	{
		left_limit = left_lim;
	}

	void set_right_limit(int right_lim)
	{
		right_limit = right_lim;
	}

	int get_left_limit() const
	{
		return left_limit;
	}

	int get_right_limit() const
	{
		return right_limit;
	}

	void set_x_ball_coord(int x_coord)
	{
		x_ball_coord = x_coord;
	}

	int get_x_ball_coord() const
	{
		 return x_ball_coord;
	}

	void set_activation(bool value)
	{
		am_I_activated = value;
	}

	bool get_activation() const
	{
		return am_I_activated;
	}

	Eball_state get_my_type() const
	{
		if (color == Ecolor::WHITE)
			return Eball_state::REGULAR;
		if (color == Ecolor::LIGHT_MAGENTA)
			return Eball_state::GOING_TO_BE_A_BOMB;
		if (color == Ecolor::RED)
			return Eball_state::BOMB;
	}

};

#endif // ! BALL_INTERFACE_H


/*
Name         | Value
|
Black        |   0
Blue         |   1
Green        |   2
Cyan         |   3
Red          |   4
Magenta      |   5
Brown        |   6
Light Gray   |   7
Dark Gray    |   8
Light Blue   |   9
Light Green  |   10
Light Cyan   |   11
Light Red    |   12
Light Magenta|   13
Yellow       |   14
White        |   15*/