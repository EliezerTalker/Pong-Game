Developed in C++ a console application Pong
game which includes: Tetris features, bomb
features and an option to play against the
computer in different difficulty levels.