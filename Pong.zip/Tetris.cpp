#include "Tetris.h"

void Tetris::move(Tetris::DIRECTION dir)
{

	/* when a board misses a ball then acoording to the matrix of the screen the falledn board will move
	    untill the avialable spot or the limit of the screen and will print him self in the coordinate to the screen*/
	bool answer = true;
	int limit;
	if (dir == DIRECTION::LEFT)
	{
		limit = game_screen->MIN_X;
	}
	else
	{
		limit = game_screen->MAX_X;
	}
	int curr_pos = fallen_board->get_x_coord();
	for (int i = 0; (i < absolute(limit - curr_pos)) && answer; i++)
	{

		answer = game_screen->is_empty_for_board(fallen_board->get_x_coord() + (int)dir, fallen_board->get_top_y_coord(), fallen_board->get_bottom_y_coord());

		if (answer)
		{
			fallen_board->board_eraser();
			fallen_board->update_location((int)dir);
			fallen_board->initialize_drawer();
			Sleep(100);
		}

	}
	game_screen->coord_mem(fallen_board->get_x_coord(), fallen_board->get_top_y_coord());
	game_screen->coord_mem(fallen_board->get_x_coord(), fallen_board->get_bottom_y_coord() - 1);
	game_screen->coord_mem(fallen_board->get_x_coord(), fallen_board->get_bottom_y_coord());
}

bool Tetris::check_and_maybe_delete_column(Tetris::DIRECTION dir, int curr_location) /* goes over the matrix of the screen and checks for a full column of boards*/
{
	int temp;
	if (game_screen->is_full_column(fallen_board->get_x_coord()))
	{
		for (int row = 3; row <= Screen::MAX_Y; row++)
		{
			temp = fallen_board->get_x_coord();
			game_screen->coord_forget(temp, row);
			game_screen->erase(temp, row);
		}

		fallen_board->set_x_coord(curr_location + (int)dir);

		for (int rows = 3; rows <= Screen::MAX_Y; rows++)
		{
			for (int i = 0; i < 5; i++)
			{
				temp = fallen_board->get_x_coord() - (i*(int)dir);
				game_screen->coord_forget(temp, rows);
				game_screen->erase(temp, rows);
			}
		}

		return true;
	}
	return false;


}
