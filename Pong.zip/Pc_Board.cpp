#include "Pc_Board.h"



/* we use this function when we want to calculate to which coordinate the ball will reach and also there is here the rand function so the computer will loose
according to the level that was chossen : NOVICE,GOOD,BEST*/
void Pc_Board::destination_calculater(int x_coord, int y_coord, Ball::Eball_direction direction)
{
	int x_dir = 1;
	int y_dir;
	if (direction == Ball::Eball_direction::LU || direction == Ball::Eball_direction::RU)
	{
		y_dir = -1;
	}
	else
	{
		y_dir = 1;
	}
	if (get_x_coord() < x_coord)
	{
		x_dir *= -1;
	}
	while (x_coord + 2 * x_dir != get_x_coord()) /* we reduce twice x_dir
												 because the middle of the ball while hit the board before the edges*/
	{
		if (y_dir == -1)
		{
			if (y_coord == Ball::Escreen_parameters::MIN_Y)
			{
				y_dir = 1;
			}
		}
		else if (y_dir == 1)
		{
			if (y_coord + 2 == Ball::Escreen_parameters::MAX_Y)
			{
				y_dir = -1;
			}
		}

		y_coord += y_dir;
		x_coord += x_dir;
	}

	final_destination = y_coord + 1;
	int missed_frequency = 1;
	if (chosen_level == Ecomputer_mode::NOVICE)
	{
		missed_frequency = rand() % 10;
	}
	if (chosen_level == Ecomputer_mode::GOOD)
	{
		missed_frequency = rand() % 40;
	}
	if (missed_frequency == 0)
	{
		final_destination = (final_destination + 5) % 19 + 5;
	}
}



/* this function tells the pc board where to move according to the destionation that the function above already calculated*/
void Pc_Board::move()
{
	
	if (get_middle_y_coord() > final_destination)
	{
		draw(get_x_coord(), get_bottom_y_coord(), ' ');
		move_up();
		draw(get_x_coord(), get_top_y_coord(), '|');
	}
	else if(get_middle_y_coord() < final_destination)
	{
		draw(get_x_coord(), get_top_y_coord(), ' ');
		move_down();
		draw(get_x_coord(), get_bottom_y_coord(), '|');
	}
}
