#ifndef UTILS_H
#define UTILS_H
 



#include <Windows.h>

BOOL gotoxy(const WORD x, const WORD y);

void hideConsoleCursor(bool hideFlag= TRUE);

void set_text_color(int color);


#endif // !UTILS_H
