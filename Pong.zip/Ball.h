#ifndef  BALL_H
#define BALL_H

using namespace std;
#include <iostream>
#include "Point.h"
#include "Regular_Ball.h"
#include "Becoming_a_Bomb.h"
#include "Bomb.h"
#define _CRT_SECURE_NO_WARNINGS
class Ball
{
public:
	
	enum Eball_corner {UPPER_LEFT=1 , UPPER_RIGHT=2};
	enum {NUM_OF_ROWS=3, NUM_OF_COLUMNS=4};
	enum Escreen_parameters{	MIN_X = 1, MAX_X = 79, MIN_Y = 3, MAX_Y = 23};
	enum Eball_direction { LU = -3, RU = 1, LD = -1, RD = 3 };
	enum class Efirst_dir { LEFT = -1, RIGHT = 1 };
private:
	Ball_Interface* ball_state;
	Regular_Ball regular_state{"sk" };     /* the ball contains three moods : a bomb a regualr ball and a going to be bomb classes*/
	Becoming_a_Bomb going_be_bomb_state;
	Bomb bomb_state;
	int dir_x ;
	int dir_y= 1;
	Point* body_arr[NUM_OF_ROWS][NUM_OF_COLUMNS]; /* this matrix  displays the ball*/
	void coord_updater();
	int x_max_lim;
	int x_min_lim;
	void draw(int coord_X, int coord_y, char ch) const;
public:
	static int where_to_start; //<===== changed
	Ball();
	Ball(const Ball& other) = delete;                /* we dont use these ctor,hence they are deleted*/
	void operator== (const Ball& other) = delete;
	~Ball();
	void initial_position();
	void move();
	int get_dir_x() const
	{
		return dir_x;
	}

	int get_dir_y() const
	{
		return dir_y;
	}
	void set_dir_x(int x)
	{
		dir_x = x;
	}

	void set_dir_y(int y)
	{
		dir_y = y;
	}

	Regular_Ball* get_regular_ball()
	{
		return &regular_state;
	}

	static void change_where_to_start()
	{
		where_to_start += 1;
	}

	static Efirst_dir get_where_to_start()
	{
		return (Efirst_dir)((where_to_start % 2) * 2 - 1);
	}

	void Complete_matrix_drawer(char ch) const; /* draws the entire ball*/
	void Eraser() const;

	const Point& get_left_edge_point() const
	{
		return *(body_arr[1][0]);
	}

	const Point& get_right_edge_point() const
	{
		return *(body_arr[1][3]);
	}


	void set_x_min_lim(int min_lim_change)
	{
		x_min_lim += min_lim_change;
	}
	void set_x_max_lim(int max_lim_change)
	{
		x_max_lim += max_lim_change;
	}

	const Point& get_upper_corner_point(Eball_corner side) const
	{
		return *body_arr[0][side];
	}

	const Point& get_lower_corner_point(Eball_corner side) const
	{
		return *body_arr[2][side];
	}


	Eball_direction get_direction() const
	{
		return (Eball_direction)(2 * this->dir_x + this->dir_y);
	}

	void set_ball_state(Ball_Interface::Eball_state wanted_state)
	{
		if (wanted_state == Ball_Interface::Eball_state::REGULAR)
			ball_state = &regular_state;
		if (wanted_state == Ball_Interface::Eball_state::GOING_TO_BE_A_BOMB)
			ball_state = &going_be_bomb_state;
		if (wanted_state == Ball_Interface::Eball_state::BOMB)
			ball_state = &bomb_state;
	}

	const Ball_Interface* get_ball_state() const
	{
		return ball_state;
	}
	Ball_Interface* get_ball_state()
	{
		return ball_state;
	}

	void change_state()
	{
		if (ball_state->get_next_ball_state() == Ball_Interface::Eball_state::GOING_TO_BE_A_BOMB)
		{
			if (ball_state->get_my_type() != Ball_Interface::Eball_state::GOING_TO_BE_A_BOMB)
			{
				ball_state->set_activation(false);
				this->set_ball_state(Ball_Interface::Eball_state::GOING_TO_BE_A_BOMB);
				ball_state->set_activation(true);
				ball_state->set_counter(0);
			}
		}
        else if (ball_state->get_next_ball_state() == Ball_Interface::Eball_state::BOMB)
		{
			if (ball_state->get_my_type() != Ball_Interface::Eball_state::BOMB)
			{
				ball_state->set_activation(false);
				this->set_ball_state(Ball_Interface::Eball_state::BOMB);
				ball_state->set_activation(true);
				ball_state->set_counter(0);
			}
		}
		 else if (ball_state->get_next_ball_state() == Ball_Interface::Eball_state::REGULAR)
		{
			if (ball_state->get_my_type() != Ball_Interface::Eball_state::REGULAR)
			{
				ball_state->set_activation(false);
				this->set_ball_state(Ball_Interface::Eball_state::REGULAR);
				ball_state->set_activation(true);
			}
		}


	}



	void set_balls_initial_coords()
	{
		
		body_arr[0][1]->set(40, 13);
		body_arr[0][2]->set(41, 13);
		
		body_arr[1][0]->set(39, 14);
		body_arr[1][1]->set(40, 14);
		body_arr[1][2]->set(41, 14);
		body_arr[1][3]->set(42, 14);


		
		body_arr[2][1]->set(40, 15);
		body_arr[2][2]->set(41, 15);
		


	}
};





#endif // ! BALL_H

