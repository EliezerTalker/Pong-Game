#ifndef  REGULAR_BALL_H
#define REGULAR_BALL_H

#include "Ball_Interface.h"
#include "Kb_Listener.h"
#include "Game_Position.h"


class Regular_Ball : public Ball_Interface, public Kb_Listener
{
public:
	enum class Erequest_bomb { NO, YES, DONT_CARE };
	enum { FIRST, SECOND, MAX_NUM_OF_CHARS };

	Erequest_bomb by_s=Erequest_bomb::NO;
	Erequest_bomb by_k=Erequest_bomb::NO;
	int freeze_count_k;
	int freeze_count_s;
	char input_keys_arr[MAX_NUM_OF_CHARS + 1];
public:


	Regular_Ball(const char* wanted_keys)
	{
		set_ball_color(Ball_Interface::Ecolor::WHITE);
		input_keys_arr[0] = wanted_keys[0];
		input_keys_arr[1] = wanted_keys[1];
		input_keys_arr[2] = '\0';
	}

	Ball_Interface::Eball_state get_next_ball_state() override
	{

		if (by_s == Erequest_bomb::YES)
		{
			by_s = Erequest_bomb::DONT_CARE;
			return Ball_Interface::Eball_state::GOING_TO_BE_A_BOMB;
		}
		if (by_k == Erequest_bomb::YES)
		{
			by_k = Erequest_bomb::DONT_CARE;
			return Ball_Interface::Eball_state::GOING_TO_BE_A_BOMB;
		}
		return Ball_Interface::Eball_state::REGULAR;
	}


	void counter_successor() override
	{
		if (Ball_Interface::get_x_ball_coord() == 40) // over here we want to count how many times the ball reached the x_coord 40
		{
			Ball_Interface::counter_successor();

		}
	}



	void handleKey(char ch) override
	{
		//if (Ball_Interface::get_activation())
	//	{
			can_I_press_Bomb_first();
			can_I_press_Bomb_second();
			if (ch == input_keys_arr[FIRST] && by_s == Erequest_bomb::NO)
			{
				by_s = Erequest_bomb::YES;
				freeze_count_s = get_counter();
			}
			if (ch == input_keys_arr[SECOND] && by_k == Erequest_bomb::NO)
			{
				by_k = Erequest_bomb::YES;
				freeze_count_k = get_counter();
			}
			Ball_Interface::set_activation(false);
		//}
	}

	void can_I_press_Bomb_first()
	{
		if (get_counter() - freeze_count_s >= 4)
		{
			by_s = Erequest_bomb::NO;
		}
	}

	void can_I_press_Bomb_second()
	{
		if (get_counter() - freeze_count_k >= 4)
		{
			by_k = Erequest_bomb::NO;
		}
	}

	const char* getKbChars() const override
	{

		return input_keys_arr;
	}

	void change_input_keys_arr_by_mode(Game_Position::Emode mode)
	{
		if (mode == Game_Position::Emode::START_H_VS_C)
		{
			input_keys_arr[1] = '\0';   /* if its  H.vs.C then we dont wont to allow the computer to use  the bobm key*/
		}
	}



};



#endif // ! REGULAR_BALL_H
