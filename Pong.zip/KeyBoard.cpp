#include "KeyBoard.h"
#include <iostream>
using namespace std;

 

 /* wants a game is over we "clean" the keyboard from all of who was registerd to him*/
void KeyBoard::zerolization()
{
	logi = 0;
	for (int i = 0; i < MAX_REGISTERD_LISTENERS; i++)
	{
		registerd_listeners[i] = nullptr;
	}
	for (int i = 0; i < NUM_OF_CHARS; i++)
	{
		keyboard_setter[i] = nullptr;
	}
}



void KeyBoard::keyboard_register(Kb_Listener* new_listener)  /* gets a user and puts him the users array*/
{
	if (logi < MAX_REGISTERD_LISTENERS)
	{
		const char*temp = new_listener->getKbChars();

		int num_of_chars = strlen(temp);
		for (int i = 0; i < num_of_chars; i++)
		{
			keyboard_setter[get_index(temp[i])] = new_listener;

		}
		registerd_listeners[logi] = new_listener;
		logi++;
	}

}

/* once the user presses a key then the keyboard inporms the board if it should move ,if the key is a menu funtion then the keybaord updates the falg of the menu/.
in addition the keyboard tells us if the ball should move or not*/
bool KeyBoard::keyboard_distributor() 
{
	
	char temp;
	int index;
	//for (int i=0;i<10;i++)
	//{
		if (_kbhit())
		{
			temp = _getch();
			temp=to_lower(temp);



			if (temp == '1' && Game_pos->get(Game_Position::EMENU::START_GAME) && ( Game_pos->get_R_if_care() == Game_Position::Ecare_pc_level::CARE || Game_pos->get_L_if_care() == Game_Position::Ecare_pc_level::CARE))
			{
				if (Game_pos->get_R_if_care() == Game_Position::Ecare_pc_level::CARE)
				{
					Game_pos->set_R_pc_level(Game_Position::Epc_level::NOVICE);
					Game_pos->set_R_if_care(Game_Position::DONT_CARE);
				}

				else //hence if (Game_pos->get_L_if_care() == Game_Position::Ecare_pc_level::CARE)
				{
					Game_pos->set_L_pc_level(Game_Position::Epc_level::NOVICE);
					Game_pos->set_L_if_care(Game_Position::DONT_CARE);
				}

				if (Game_pos->get_R_if_care() == Game_Position::Ecare_pc_level::DONT_CARE && Game_pos->get_L_if_care() == Game_Position::Ecare_pc_level::DONT_CARE)
				{
					Game_pos->set(Game_Position::EMENU::EXIT_LEVEL_MENU, true);
					should_ball_move = true;
				}

			

			}


			else if (temp == '2' && Game_pos->get(Game_Position::EMENU::START_GAME) && (Game_pos->get_R_if_care() == Game_Position::Ecare_pc_level::CARE || Game_pos->get_L_if_care() == Game_Position::Ecare_pc_level::CARE))
			{
				if (Game_pos->get_R_if_care() == Game_Position::Ecare_pc_level::CARE)
				{
					Game_pos->set_R_pc_level(Game_Position::Epc_level::GOOD);
					Game_pos->set_R_if_care(Game_Position::DONT_CARE);
				}

				else //hence if (Game_pos->get_L_if_care() == Game_Position::Ecare_pc_level::CARE)
				{
					Game_pos->set_L_pc_level(Game_Position::Epc_level::GOOD);
					Game_pos->set_L_if_care(Game_Position::DONT_CARE);
				}
				if (Game_pos->get_R_if_care() == Game_Position::Ecare_pc_level::DONT_CARE && Game_pos->get_L_if_care() == Game_Position::Ecare_pc_level::DONT_CARE)
				{
					Game_pos->set(Game_Position::EMENU::EXIT_LEVEL_MENU, true);
					should_ball_move = true;
				}

				if (!(Game_pos->get_R_if_care() == Game_Position::Ecare_pc_level::DONT_CARE && Game_pos->get_L_if_care() == Game_Position::Ecare_pc_level::DONT_CARE))
				{
					Game_pos->set(Game_Position::EMENU::REQ_LEVEL_MENU, true);
				}
			}

			else if (temp == '3' && Game_pos->get(Game_Position::EMENU::START_GAME) && (Game_pos->get_R_if_care() == Game_Position::Ecare_pc_level::CARE || Game_pos->get_L_if_care() == Game_Position::Ecare_pc_level::CARE))
			{
				if (Game_pos->get_R_if_care() == Game_Position::Ecare_pc_level::CARE)
				{
					Game_pos->set_R_pc_level(Game_Position::Epc_level::BEST);
					Game_pos->set_R_if_care(Game_Position::DONT_CARE);
				}

				else //hence if (Game_pos->get_L_if_care() == Game_Position::Ecare_pc_level::CARE)
				{
					Game_pos->set_L_pc_level(Game_Position::Epc_level::BEST);
					Game_pos->set_L_if_care(Game_Position::DONT_CARE);
				}
				if (Game_pos->get_R_if_care() == Game_Position::Ecare_pc_level::DONT_CARE && Game_pos->get_L_if_care() == Game_Position::Ecare_pc_level::DONT_CARE)
				{
					Game_pos->set(Game_Position::EMENU::EXIT_LEVEL_MENU, true);
					should_ball_move = true;
				}
			}

			else if (temp == '1')
			{
				should_ball_move = true;
				Game_pos->set(Game_Position::EMENU::START_GAME, true);
				Game_pos->set_mode(Game_Position::Emode::START_H_VS_H);
			}


			else if (temp == '2')
			{
				should_ball_move = false;
				Game_pos->set(Game_Position::EMENU::START_GAME, true);
				Game_pos->set_mode(Game_Position::Emode::START_H_VS_C);
				Game_pos->set_R_if_care(Game_Position::Ecare_pc_level::CARE);
				Game_pos->set(Game_Position::EMENU::REQ_LEVEL_MENU, true);
			}

			else if (temp == '3')
			{
				should_ball_move = false;
				Game_pos->set(Game_Position::EMENU::START_GAME, true);
				Game_pos->set_mode(Game_Position::Emode::START_C_VS_C);
				Game_pos->set_R_if_care(Game_Position::Ecare_pc_level::CARE);
				Game_pos->set_L_if_care(Game_Position::Ecare_pc_level::CARE);
				Game_pos->set(Game_Position::EMENU::REQ_LEVEL_MENU, true);

			}


			else if (temp == '4')
			{
				should_ball_move = true;
				Game_pos->set(Game_Position::EMENU::EXIT_PAUSE, true);
				

			}

		
			else if (temp == '8')
			{
				should_ball_move = false;
				Game_pos->set(Game_Position::EMENU::REQ_INFO, true);


			}

			else if (temp == '6')
			{
				should_ball_move = false;
				Game_pos->set(Game_Position::EMENU::EXIT_INFO, true);


			}





			else if (temp == ESCAPE)
			{
				
				should_ball_move = false;
				Game_pos->set(Game_Position::EMENU::REQ_PAUSE, true);

			}


			/*
			else if (temp == '8') // if the player wanted insterctions
			{
				should_ball_move = false;
				start_game = NO;
				system("cls");
				cout << "In our Pong game, once a player misses the ball a copy of his board will drop"<<endl;
				cout << "as in tetris game to the lowest position on his side of the screen" << endl;
				cout << "and the new position of the board will go up by one, making him one step closer to losing." << endl;
				cout << "In case dropped boards complete a full line, the entire line would disappear" << endl;
				cout << "and the board would gain back five lines." << endl;
				cout << "The player whose board reaches the position of quarter of screen - loses." << endl;
				cout << endl << "Keys:" << endl;
				cout << endl << "for the left player:" << endl;
				cout << "press 'q' or 'Q' to go up," << endl;
				cout << "press 'a' or 'A' to go down." << endl;
				cout << endl << "for the left player:" << endl;
				cout << "press 'p' or 'P' to go up," << endl;
				cout << "press 'l' or 'L' to go down." << endl;
				cout << endl << "to return to the menu please press 6" << endl;
			}
			*/
	

			else if (temp == '9') /* if the player wants to exit the game*/
			{

				Game_pos->set(Game_Position::EMENU::EXIT, true);
				should_ball_move = false;
			}

			else if (Game_pos->get(Game_Position::EMENU::IN_GAME) && (!Game_pos->get(Game_Position::EMENU::IN_INFO)) && (!Game_pos->get(Game_Position::EMENU::IN_PAUSE)))
			{
				should_ball_move = true;
				index = get_index(temp);
				if (keyboard_setter[index] && index >= FIRST_INDEX && index < NUM_OF_CHARS)
					keyboard_setter[index]->handleKey(temp); /* infroms the players if they have to move*/
			}

		}
	
//	}
	return should_ball_move;
}
