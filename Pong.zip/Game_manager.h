#ifndef GAME_MANAGER_H
#define  GAME_MANAGER_H

#include "Game_objects.h"
#include "Game_stack.h"
#define _CRT_SECURE_NO_WARNINGS



class Game_manager {

	Game_stack stack;
	Menu menu_of_game;
	KeyBoard game_keyboard;
	Game_objects * new_game = new Game_objects();

public:
	void manage_game();   /*this function will start the game and handle the memory of the game*/

};

#endif // !GAME_MANAGER_H

