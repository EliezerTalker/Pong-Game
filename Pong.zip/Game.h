#ifndef  GAME_H
#define GAME_H

#include "Menu.h"
#include "Board.h"
#include "Ball.h"
#include "KeyBoard.h"
#include "Screen.h"
#include "Tetris.h"
#include "UserBoard.h"
#include "Pc_Board.h"

class Game_manager;

class Game {
public:
	enum {LEFT_LOSE=20, RIGHT_LOSE=60};
	enum { MESSAGE_ONE , MESSAGE_EIGHT=2 ,MESSAGE_NINE};
	enum { LEFT= 1 , RIGHT= -1 };
	enum { LEFT_PLAYER, RIGHT_PLAYER };
	enum { START_LEFT_BOARD = 4, START_RIGHT_BOARD = 76 };
	enum Eball_mode {OLD_BALL,NEW_BALL};
private:
	
	KeyBoard *game_keyboard; 
	Screen game_screen;
	Menu* game_menu;
	Board* left_player;
	Board* right_player;
	User_Board us[2] = { { 10, 12, 4, "qa" } ,{ 11, 13, 76, "pl" } };
	Pc_Board pc[2] = { { 10, 12, 4 } ,{ 11, 13, 76 } };
	
	Ball game_ball;
	Tetris game_tetris;
	Board::ball_position Pos_l = Board::ball_position::AWAY;
	Board::ball_position Pos_r = Board::ball_position::AWAY;
	int should_print_start_up_menu = true;
	int starting_new_game = true;
	bool did_some_one_lose = false; 
	Eball_mode ball_state = NEW_BALL;
	Ball_Interface::Eball_state current_type;
	void which_game();

	friend class Game_manager;
public:


	void set_game_menu(Menu* game_menu)
	{
				
		this->game_menu = game_menu;
	}
	void game_initializer();

	void play_game();

	void set_keyboard(KeyBoard* game_keyboard_to_set)
	{
		game_keyboard = game_keyboard_to_set;
	}
	

	bool get_did_some_one_lose_game() 
	{
		return did_some_one_lose;
	}

	void set_did_someone_lose(bool decision)
	{
		did_some_one_lose = decision;
	}


	Ball* get_game_ball()  // <===== changed
	{
		return &game_ball;
	}

	int check_hit_dead_board();

};








#endif // ! GAME_H
