#ifndef GAME_STACK_H
#define GAME_STACK_H

#include "Game_objects.h"
 /*  this stack will be used in order to free the memory of a old game once the user wants to start a new one*/
class Game_stack
{
	game_objects* top=nullptr;
	game_objects* next=nullptr;
	game_objects* tail = top;

public:

	void push(game_objects* item);

	void pop();

	bool is_empty()
	{
		return(top == nullptr);
	}

};



#endif // !GAME_STACK_H
