#ifndef  USER_BOARD_H
#define USER_BOARD_H

#include "Board.h"
#include "Kb_Listener.h"

#define _CRT_SECURE_NO_WARNINGS

class User_Board : public Board , public Kb_Listener {
public:
	enum{ UP ,DOWN ,NUM_OF_CHARS_TO_USE,DONT_MOVE=-1};
	
private:
	char my_chars_arr[NUM_OF_CHARS_TO_USE+1];  // [0] = UP [1]= DOWN
	char dir = DONT_MOVE;

public:
	
	User_Board(int Top_y, int Bottom_y, int Board_location,const char* mychars) : Board(Top_y,Bottom_y,Board_location)
	{
		my_chars_arr[0] = mychars[0];
		my_chars_arr[1] = mychars[1];
		my_chars_arr[2] = '\0';

	}
	const char* getKbChars() const override

	{
		return my_chars_arr;
	}
		
	void move();

	void handleKey(char k) override
	{
		dir = k;
	}
};


#endif // ! USER_BOARD_H