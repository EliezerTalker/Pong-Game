#include "UserBoard.h"


/* this function is used to move the human player board*/
void User_Board::move()
{
	if (dir == DONT_MOVE)
	{
		return;
	}
	/* we check in what direction the board should move and handle appropriately*/
	if (dir == my_chars_arr[UP])
	{

		if (get_top_y_coord() > MIN_Y)
		{
			draw(get_x_coord(), get_bottom_y_coord(), ' ');
			move_up();
			draw(get_x_coord(), get_top_y_coord(), '|');
		}
	}
	if (dir == my_chars_arr[DOWN])
	{



		if (get_bottom_y_coord() < MAX_Y)
		{
			draw(get_x_coord(), get_top_y_coord(), ' ');
			move_down();
			draw(get_x_coord(), get_bottom_y_coord(), '|');
		}
	}
	dir = DONT_MOVE;
}





