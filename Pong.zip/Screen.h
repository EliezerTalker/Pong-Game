#ifndef  SCREEN_H
#define SCREEN_H
#include "Board.h"
#include "Ball.h"

class Screen
{
public:
	enum { MIN_X = 0, MAX_X = 79, MIN_Y = 0, MAX_Y = 23, AVAILABLE=0 };
	enum { LEFT_PLAYER, RIGHT_PLAYER, MAX_REGISTERD_BOARDS = 2 };
private:
	char screen_display[MAX_Y + 1][MAX_X + 1] = {0};  /* this matrix will indicate  where boards of tetris function are printed*/
	Board *players[MAX_REGISTERD_BOARDS];
	int logi = 0;

	void coord_mem(int x, int y, char ch)   /* tell the matrix in which coordiate a char was printed*/
	{
		screen_display[y][x] = ch;
	}
public:

	void player_register(Board* player_to_register)
	{
		if (logi < MAX_REGISTERD_BOARDS)
		{
			players[logi] = player_to_register;
			logi++;
		}
	}

	int get_left_limit() const
	{
		return players[LEFT_PLAYER]->get_x_coord();
	}
	int get_right_limit() const
	{
		return players[RIGHT_PLAYER]->get_x_coord();
	}
	void set_left_lim(Ball* ball_to_set, int change)
	{
		ball_to_set->set_x_min_lim(change);
		
	}
	void set_right_lim(Ball* ball_to_set, int change)
	{
		ball_to_set->set_x_max_lim(change);
	}

	bool is_empty(int x_coord, int y_coord)
	{
		return (screen_display[y_coord][x_coord] == AVAILABLE);
	}
	bool is_empty_for_board(int x_coord, int y_max_coord, int y_min_coord)
	{
		return (is_empty(x_coord,y_max_coord)  && is_empty(x_coord, y_min_coord)); ////// to remember that we changed it!!!!
	}

	void coord_mem(int x,int y)  /* just call this function the call the function above with the cahr '1'*/
	{
		coord_mem(x, y, '1');
	}

	void coord_forget(int x, int y) /* here we can update the matrix if a char no longer appears on the screen*/
	{
		coord_mem(x, y, 0);
	}
	void forget_column(int x) /* here we can update the matrix if a char no longer appears on the screen*/
	{
		
		for(int r =0; r<= MAX_Y ; r++)
			coord_mem(x, r, 0);
	}

	bool is_full_column(int column) /* checks if there is a full column with the same char*/
	{
		for (int r = 4;r <= MAX_Y;r++)
		{
			if (screen_display[r][column] != '1')
				return false;
		}
		return true;
	}

	void erase(int x, int y) /* deleted from the screen what was printed at a given location*/
	{
		gotoxy(x, y);
		cout << " ";
	}

	void erase_column(int x) /* here we can update the matrix if a char no longer appears on the screen*/
	{

		for (int r = 0; r <= MAX_Y; r++)
			erase(x, r);
	}

	void complete_screen_drawer(char ch);
	
};









#endif // ! SCREEN_H
