#include "Game_manager.h"

void Game_manager::manage_game()
{
	game_keyboard.set_menu((menu_of_game.get_mode()));
	new_game->our_game.set_game_menu(&menu_of_game);       /* over here we give the game all of the parameters that it needs*/
	new_game->our_game.set_keyboard(&game_keyboard);
	new_game->our_game.game_initializer();
	
	stack.push(new_game);
	Game_objects *temp;
	while (!stack.is_empty())
	{
		new_game->our_game.play_game(); /* here we start to play*/

		if (!menu_of_game.get_mode()->get(Game_Position::EMENU::EXIT))
		{
			if (!new_game->our_game.get_did_some_one_lose_game())
			{
				stack.pop();
				temp = new Game_objects();
				new_game = temp;
				new_game->our_game.set_game_menu(&menu_of_game);       /* over here we give the game all of the parameters that it needs*/
				new_game->our_game.set_keyboard(&game_keyboard);
				new_game->our_game.game_initializer();
				new_game->our_game.which_game();
				new_game->our_game.game_ball.change_where_to_start();
				system("cls");
				new_game->our_game.left_player->initialize_drawer();
				new_game->our_game.right_player->initialize_drawer();
				new_game->our_game.game_ball.initial_position();
				new_game->our_game.game_ball.Complete_matrix_drawer('O');
				menu_of_game.get_mode()->zeroization_of_mods();
				menu_of_game.get_mode()->set(Game_Position::EMENU::IN_GAME, true);
				stack.push(new_game);
			}
			
			else // someone lost
			{
				system("cls");
				gotoxy(36, 12);
				cout << "GAME OVER!!!!" << endl;
				Sleep(4000);
				system("cls");
				stack.pop();     /* we delete the old game because we a new one is requested*/
				temp = new Game_objects();
				new_game = temp;
				new_game->our_game.set_game_menu(&menu_of_game);       /* over here we give the game all of the parameters that it needs*/
				new_game->our_game.set_keyboard(&game_keyboard);
				new_game->our_game.game_initializer();
				new_game->our_game.game_ball.change_where_to_start();
				menu_of_game.get_mode()->zeroization_of_mods();
				stack.push(new_game);
				

			}




		}
		else /* if the user requested to exit the game*/
		{
			stack.pop();
			cout << "GOOD BYE" << endl;
			Sleep(500);

		}


	}
























	/*

	while (stack.is_empty() == false) // we will keep on playing as long as the stack is not empty,hence the user yet wants to play
	{

		new_game->our_game.play_game();  // over here we start the game
		new_game->our_game.get_game_ball()->where_to_start = new_game->our_game.get_game_ball()->where_to_start + 1; // <===changed
		if (new_game->our_game.get_did_some_one_lose_game() == true)  // if someone lost the we will want to delete the old game and start a new one
		{
			new_game->our_game.set_did_someone_lose(false);

			// over here we set the lines of the menu that we will want to print

			menu_of_game.option_message_coord_setter(3, menu_of_game.option_message_x_get(2), menu_of_game.option_message_y_get(2));
			menu_of_game.option_message_coord_setter(2, menu_of_game.option_message_x_get(1), menu_of_game.option_message_y_get(1));
			menu_of_game.option_message_coord_setter(1, menu_of_game.option_message_x_get(3), menu_of_game.option_message_y_get(3) + 1);
			system("cls");
			Game_objects * temp = new Game_objects[1]; // we make a new game
			stack.pop(); // here we delete the old game
			gotoxy(35, 13);
			cout << "game over!!" << endl;
			Sleep(5000);
			system("cls");
			new_game = temp;
			stack.push(new_game); //we put the ne game on the stack
			new_game->our_game.set_game_menu(&menu_of_game);
			new_game->our_game.set_keyboard(&game_keyboard);
			//	menu_of_game.set_start_over(false);
			new_game->our_game.game_initializer();


		}

		else if (menu_of_game.get_should_start_over() == true && game_keyboard.get_termination_mode() == false) // if the user wants to startover while in a game
		{
			Game_objects * temp = new Game_objects[1]; // we make a new game
			
			stack.pop(); //delete the old game
			new_game = temp;
			stack.push(new_game); // put the new game in the stack
			new_game->our_game.set_game_menu(&menu_of_game);
			new_game->our_game.set_keyboard(&game_keyboard);
			menu_of_game.set_start_over(false);
			new_game->our_game.game_initializer();
			system("cls");
			for (int i = 0; i < game_keyboard.get_num_of_registerd_players(); i++)   // here we draw the boards again
			{
				game_keyboard.get_registerd_board_at(i)->initialize_drawer();
			}
		}

		else	if (game_keyboard.get_termination_mode() == true) //if the user wants to exit the game
		{
			stack.pop(); //we delete the old game
			system("cls");
			exit(1);
		}
	}
	*/
}
