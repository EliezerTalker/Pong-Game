#include "Ball.h"

int::Ball::where_to_start = 0;

void Ball::coord_updater()
{
	
	for (int i = 0; i < NUM_OF_ROWS; i++)   /* this loop updates the ball location*/
	{

		for (int j = 0; j < NUM_OF_COLUMNS; j++)
		{
			if (body_arr[i][j] != nullptr)
			{
				body_arr[i][j]->set_x(body_arr[i][j]->get_x() + dir_x);
				body_arr[i][j]->set_y(body_arr[i][j]->get_y() + dir_y);
			}
		}
	}
}

	Ball::~Ball()   /* over here we free the memory we allocated*/
	{
		for (int i = 0; i < NUM_OF_ROWS; i++)
		{
			for (int j = 0; j < NUM_OF_COLUMNS; j++)
			{
				if (body_arr[i][j])
				{
					delete body_arr[i][j];
				}
			}
		}
	}

void Ball::initial_position()    /* when the game just starts this will be the balls location*/
{
	body_arr[0][0] = nullptr;
	body_arr[0][1] = new Point(40, 13, 'O');
	body_arr[0][2] = new Point(41, 13, 'O');
	body_arr[0][3] = nullptr;


	body_arr[1][0] = new Point(39, 14, 'O');
	body_arr[1][1] = new Point(40, 14, 'O');
	body_arr[1][2] = new Point(41, 14, 'O');
	body_arr[1][3] = new Point(42, 14, 'O');


	body_arr[2][0] = nullptr;
	body_arr[2][1] = new Point(40, 15, 'O');
	body_arr[2][2] = new Point(41, 15, 'O');
	body_arr[2][3] = nullptr;
}


Ball::Ball()   
{ 
	dir_x = (where_to_start%2 )*2-1; // <===== changed
	this->x_max_lim = 0;
	this->x_min_lim = 0;
	ball_state = &regular_state;
}

void Ball::move()
{
	if (body_arr[2][1]->get_y() == MAX_Y)
		dir_y = -1;

	if (body_arr[0][1]->get_y() == MIN_Y)
			dir_y = 1;
	if (ball_state->get_my_type() == Ball_Interface::Eball_state::REGULAR)
	{
		if (body_arr[1][3]->get_x() == x_max_lim)               /*      in these 4 if"s we check if the ball has reached the corner of the screen
																and handle the direction of the ball if needed                */
		{
			this->Eraser();
			this->initial_position();
		}
		if (body_arr[1][0]->get_x() == x_min_lim)
		{
			this->Eraser();
			this->initial_position();
		}
	}
	/* in this swtich we handle the balls movment according to its direction*/
	switch (2 * this->dir_x + this->dir_y)
	{

	case (LD):
	{
		draw(body_arr[0][1]->get_x(), body_arr[0][1]->get_y(), ' ');
		draw(body_arr[0][2]->get_x(), body_arr[0][2]->get_y(), ' ');
		draw(body_arr[1][2]->get_x(), body_arr[1][2]->get_y(), ' ');
		draw(body_arr[1][3]->get_x(), body_arr[1][3]->get_y(), ' ');
		this->coord_updater();
		draw(body_arr[1][0]->get_x(), body_arr[1][0]->get_y(), body_arr[1][0]->get_char());
		draw(body_arr[1][1]->get_x(), body_arr[1][1]->get_y(), body_arr[1][1]->get_char());
		draw(body_arr[2][1]->get_x(), body_arr[2][1]->get_y(), body_arr[2][1]->get_char());
		draw(body_arr[2][2]->get_x(), body_arr[2][2]->get_y(), body_arr[2][2]->get_char());
		break;

	}
	case (RD):
	{
		draw(body_arr[0][1]->get_x(), body_arr[0][1]->get_y(), ' ');
		draw(body_arr[0][2]->get_x(), body_arr[0][2]->get_y(), ' ');
		draw(body_arr[1][0]->get_x(), body_arr[1][0]->get_y(), ' ');
		draw(body_arr[1][1]->get_x(), body_arr[1][1]->get_y(), ' ');
		this->coord_updater();
		draw(body_arr[1][2]->get_x(), body_arr[1][2]->get_y(), body_arr[1][2]->get_char());
		draw(body_arr[1][3]->get_x(), body_arr[1][3]->get_y(), body_arr[1][3]->get_char());
		draw(body_arr[2][1]->get_x(), body_arr[2][1]->get_y(), body_arr[2][1]->get_char());
		draw(body_arr[2][2]->get_x(), body_arr[2][2]->get_y(), body_arr[2][2]->get_char());
		break;
	}
	case (RU):
	{
		draw(body_arr[2][1]->get_x(), body_arr[2][1]->get_y(), ' ');
		draw(body_arr[2][2]->get_x(), body_arr[2][2]->get_y(), ' ');
		draw(body_arr[1][0]->get_x(), body_arr[1][0]->get_y(), ' ');
		draw(body_arr[1][1]->get_x(), body_arr[1][1]->get_y(), ' ');
		this->coord_updater();
		draw(body_arr[1][2]->get_x(), body_arr[1][2]->get_y(), body_arr[1][2]->get_char());
		draw(body_arr[1][3]->get_x(), body_arr[1][3]->get_y(), body_arr[1][3]->get_char());
		draw(body_arr[0][1]->get_x(), body_arr[0][1]->get_y(), body_arr[0][1]->get_char());
		draw(body_arr[0][2]->get_x(), body_arr[0][2]->get_y(), body_arr[0][2]->get_char());
		break;

	}
	case (LU):
	{
		draw(body_arr[1][2]->get_x(), body_arr[1][2]->get_y(), ' ');
		draw(body_arr[1][3]->get_x(), body_arr[1][3]->get_y(), ' ');
		draw(body_arr[2][1]->get_x(), body_arr[2][1]->get_y(), ' ');
		draw(body_arr[2][2]->get_x(), body_arr[2][2]->get_y(), ' ');
		this->coord_updater();
		draw(body_arr[0][1]->get_x(), body_arr[0][1]->get_y(), body_arr[0][1]->get_char());
		draw(body_arr[0][2]->get_x(), body_arr[0][2]->get_y(), body_arr[0][2]->get_char());
		draw(body_arr[1][0]->get_x(), body_arr[1][0]->get_y(), body_arr[1][0]->get_char());
		draw(body_arr[1][1]->get_x(), body_arr[1][1]->get_y(), body_arr[1][1]->get_char());
		break;

	}






	} // end switch

}





void Ball::draw(int coord_X, int coord_y, char ch) const
{
	gotoxy(coord_X, coord_y);
	cout << ch;



}



void Ball::Eraser() const
{

	this->Complete_matrix_drawer(' ');



}



void Ball::Complete_matrix_drawer(char ch) const
{
	for (int r = 0;r < NUM_OF_ROWS; r++)
	{
		for (int c = 0; c < NUM_OF_COLUMNS; c++)
		{
			if (body_arr[r][c] != nullptr)
			{
				draw(body_arr[r][c]->get_x(), body_arr[r][c]->get_y(), ch);
			}
		}
	}
}
