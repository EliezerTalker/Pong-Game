#include "Menu.h"




void Menu::print_main_menu_display(Edisplay_mode mode)
{
	for (int i = 0; i < 3; i++)
	{
		options_arr[i].message_printer();
	}
	if (mode == MAIN_DISPLAY)
	{
		options_arr[3].Set_starting_point(0, 6);
		options_arr[4].Set_starting_point(0, 4);
		options_arr[5].Set_starting_point(0, 5);
	}


	else
	{
		options_arr[3].Set_starting_point(0, 4);
		options_arr[4].Set_starting_point(0, 5);
		options_arr[5].Set_starting_point(0, 6);

	}

	for (int i = 3; i < 6; i++)
	{
		if ((i != 3 || mode == PAUSE_DISPLAY))
		{
			options_arr[i].message_printer();
		}

	}
}

void Menu::printed_messages_deleter()
{
	for (int i=0 ; i<4 ; i++)
	{
		options_arr[i].messages_print_deleter();
	
	}

	
}



void Menu::level_options_printer()
{
	for (int i = 0; i < NUM_OF_OPTIONS_FOR_LEVEL; i++)
	{
		level_options_arr[i].message_printer();
	}
}

