#ifndef KB_LISTENER_H
#define KB_LISTENER_H


 /* all of the class that will want to register to the keyboard will need to inhert this class*/
struct Kb_Listener {
	virtual void handleKey(char k) = 0;
	virtual const char* getKbChars() const = 0;
};




#endif // !KB_LISTENER_H
