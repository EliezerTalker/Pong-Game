#ifndef MENU_H
#define MENU_H

#include "Menu_Option.h"
#include "Game_Position.h"
#include <iostream>
using namespace std;

class Menu
{
public:
	enum Edisplay_mode {MAIN_DISPLAY,PAUSE_DISPLAY };
private:
	enum {NUM_OF_OPTIONS=6};
	enum { NUM_OF_OPTIONS_FOR_LEVEL=3};
	Game_Position menu_mode;
	Menu_Option options_arr[NUM_OF_OPTIONS];    /* this array hold all of the option presented at the menu*/
	Menu_Option level_options_arr[NUM_OF_OPTIONS_FOR_LEVEL]; 
	bool start_over = false; /* a flag so the menu will know if it should adjust the messages that are appeared if a game has already been
							           played */
public:

	Menu() :
		options_arr{ {"(1) Start a new game - Human vs Human", 0, 1 }, {"(2) Start a new game - Human vs Computer", 0, 2},
		{"(3) Start a new game - Computer vs Computer", 0, 3},{ "(4) Continue a paused game", 0, 4 },{ "(8) Present instructions and keys", 0, 5 } ,{"(9) EXIT", 0, 6} }
		, level_options_arr{ { "(1) NOVICE LEVEL", 0, 1 },{ "(2) GOOD LEVEL" , 0, 2 },{ "(3) BEST LEVEL ", 0, 3  } } {}
		
	
	void print_main_menu_display(Edisplay_mode mode);

	void message_printer(int option_num) 
	{
		options_arr[option_num].message_printer();
	}

	void printed_messages_deleter();

	void level_options_printer();

	void option_message_coord_setter(int num_of_option, int x, int y) /* here we set where the message will appear of the screen,if printed*/
	{
		options_arr[num_of_option].Set_starting_point(x, y);
	}

	int option_message_x_get(int num)  const
	{
		return options_arr[num].get_Strater_x();
	}


	int option_message_y_get(int num) const
	{
		return options_arr[num].get_Strater_y();
	}

	bool get_should_start_over()
	{
		return start_over;
	}

	void set_start_over(bool set_value)
	{
		start_over = set_value;
	}


	Game_Position* get_mode()
	{
		return &menu_mode;
	}


};

#endif // !MENU_H

