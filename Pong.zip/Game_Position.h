#ifndef   GAME_POSITION_H
#define  GAME_POSITION_H


/* this class is a class that is contained in the menu and the menu send only this small class to the keyboard so it will be update it according the menu function that is requested*/
class Game_Position {

public:
	enum Ecare_pc_level{DONT_CARE, CARE};
	enum Epc_level { NOVICE ,GOOD,BEST};
	enum Emode {START_H_VS_H = 0, START_H_VS_C = 1, START_C_VS_C = 3,};
	enum EMENU{START_GAME, IN_GAME , REQ_PAUSE , IN_PAUSE ,EXIT_PAUSE, REQ_INFO , IN_INFO ,EXIT_INFO, EXIT,REQ_LEVEL_MENU,IN_LEVEL_MENU,EXIT_LEVEL_MENU, NUM_OF_MODS };
private:
	Epc_level L_pc_level;
	Epc_level R_pc_level;
	Ecare_pc_level L_if_care = DONT_CARE;
	Ecare_pc_level R_if_care = DONT_CARE;
	Emode mode;
	bool position_arr[NUM_OF_MODS] = {0};
	 

public:


	void set(EMENU m, bool new_value)
	{
		position_arr[m] = new_value;

	}


	bool get(EMENU m)
	{
		return position_arr[m];
	}


	void set_mode(Emode new_mode)
	{
		mode = new_mode;

	}


	Emode get_mode()
	{
		return mode;

	}


	void zeroization_of_mods()
	{
	    set(Game_Position::EMENU::IN_GAME, false);
	    set(Game_Position::EMENU::START_GAME, false);
		set(Game_Position::EMENU::REQ_PAUSE, false);
		set(Game_Position::EMENU::REQ_INFO, false);
		set(Game_Position::EMENU::IN_PAUSE, false);
		set(Game_Position::EMENU::IN_INFO, false);
		set(Game_Position::EMENU::EXIT_PAUSE, false);
		set(Game_Position::EMENU::EXIT_INFO, false);
		set(Game_Position::EMENU::EXIT, false);

	}


	void set_L_if_care(Ecare_pc_level value)
	{
		L_if_care = value;
	}

	Ecare_pc_level get_L_if_care()
	{
		return L_if_care;
	}


	void set_R_if_care(Ecare_pc_level value)
	{
		R_if_care = value;
	}

	Ecare_pc_level get_R_if_care()
	{
		return R_if_care;
	}


	Epc_level get_L_pc_level()
	{
		return L_pc_level;
	}
	void set_L_pc_level(Epc_level value)
	{
		L_pc_level = value;
	}



	Epc_level get_R_pc_level()
	{
		return R_pc_level;
	}
	void set_R_pc_level(Epc_level value)
	{
		R_pc_level = value;
	}
};



#endif // !  GAME_POSITION_H
