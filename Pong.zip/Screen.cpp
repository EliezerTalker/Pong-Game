#include "Screen.h"

void Screen::complete_screen_drawer(char ch)   /* goes over the matrix and where ever something should appear on the screen
											       , it will bee printed the the correct coordinates*/
{
	for (int row = 0; row < MAX_Y + 1; row++)
	{
		for (int column = 0; column < MAX_X + 1; column++)
		{
			if (screen_display[row][column] != 0)
			{
				gotoxy(column, row);
				cout << ch;
			}
		}
	}
}
