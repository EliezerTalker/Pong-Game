#include "Board.h"




Board::ball_position Board::check_ball_position
(const Ball & ball_to_check, const Point & point_to_check, int flag) const
{

	int ball_direction;
	int position = (point_to_check.get_x() - this->bottom_point.get_x()) *flag;   /* here we calculate the balls current position*/

	if (position == 1)
	{
		// here we check if the ball is going to hit the board
		if (this->bottom_point.get_y() >= point_to_check.get_y()
			&& this->top_point.get_y() <= point_to_check.get_y())
		{
			return ball_position::CENTER_HIT;
		}
		ball_direction = ball_to_check.get_dir_x() * 2 + ball_to_check.get_dir_y();
		if ((ball_direction == Ball::LD || ball_direction == Ball::RD)           /* this if checks if its a corner hit*/
			&& point_to_check.get_y() == (top_point.get_y() - 1)
			|| (ball_direction == Ball::LU || ball_direction == Ball::RU)
			&& point_to_check.get_y() == (bottom_point.get_y() + 1))
		{
			return ball_position::CORNER_HIT;
		}
		if (ball_to_check.get_ball_state()->get_my_type() == Ball_Interface::Eball_state::REGULAR)
			return ball_position::MISSED;
	}
	if (position < 1 || (position == 1 && ball_to_check.get_ball_state()->get_my_type() != Ball_Interface::Eball_state::REGULAR))
		return ball_position::AFTER_BOARD;
	return ball_position::AWAY; /*if position is not 1 then the ball is away*/
}
