#ifndef BECOMING_A_BOMB_H
#define  BECOMING_A_BOMB_H

#include "Ball_Interface.h"

class Becoming_a_Bomb :public Ball_Interface
{

	bool did_hit_board = false;


public:


	Becoming_a_Bomb()
	{

		set_ball_color(Ball_Interface::Ecolor::LIGHT_MAGENTA);

	}


	void counter_successor() override
	{
		if (Ball_Interface::get_activation())
		{
			Ball_Interface::counter_successor();
		}
	}

	/*this function tells us the balls next state*/
	Ball_Interface::Eball_state get_next_ball_state() override
	{
		if (Ball_Interface::get_activation() && Ball_Interface::get_counter() == 8 && !did_hit_board)
		{
			//Ball_Interface::set_activation(false);
			//Ball_Interface::set_counter(0);
			return Ball_Interface::Eball_state::BOMB;
		}
		else if (Ball_Interface::get_activation() && did_hit_board)
		{
			//Ball_Interface::set_activation(false);
			did_hit_board = false;
			Ball_Interface::set_counter(0);
			return Ball_Interface::Eball_state::REGULAR;
		}
		else
		{
			return Ball_Interface::Eball_state::GOING_TO_BE_A_BOMB;
		}
	}

	

};


#endif // !BECOMING_A_BOMB_H
