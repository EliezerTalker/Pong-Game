#include "Game.h"


 
/* this function updates the game information according to the option that is choosen : H VS H, H VS C , C VS C */
void Game::which_game()
{ 
	game_ball.initial_position();
	if (game_menu->get_mode()->get_mode() == Game_Position::Emode::START_H_VS_H)
	{
		left_player = &us[LEFT_PLAYER];
		right_player = &us[RIGHT_PLAYER];
		game_keyboard->keyboard_register(&us[LEFT_PLAYER]);
		game_keyboard->keyboard_register(&us[RIGHT_PLAYER]);
		game_keyboard->keyboard_register(game_ball.get_regular_ball());
		game_ball.get_regular_ball()->set_activation(true);
	}

	if (game_menu->get_mode()->get_mode() == Game_Position::Emode::START_H_VS_C)
	{
		system("cls");
		
		left_player = &us[LEFT_PLAYER];
		game_keyboard->keyboard_register(&us[LEFT_PLAYER]);
		right_player = &pc[RIGHT_PLAYER];
		game_ball.get_regular_ball()->change_input_keys_arr_by_mode(Game_Position::Emode::START_H_VS_C);
		game_keyboard->keyboard_register(game_ball.get_regular_ball());
		if (game_ball.get_where_to_start() == Ball::Efirst_dir::RIGHT)
		{
			Point temp1 = game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_RIGHT);
			pc[RIGHT_PLAYER].destination_calculater(temp1.get_x(), temp1.get_y(), game_ball.get_direction());
		}
	}

	if (game_menu->get_mode()->get_mode() == Game_Position::Emode::START_C_VS_C)
	{
		left_player = &pc[LEFT_PLAYER];
		right_player = &pc[RIGHT_PLAYER];
		if (game_ball.get_where_to_start() == Ball::Efirst_dir::RIGHT)
		{
			Point temp2 = game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_RIGHT);
			pc[RIGHT_PLAYER].destination_calculater(temp2.get_x(), temp2.get_y(), game_ball.get_direction());
		}
		if (game_ball.get_where_to_start() == Ball::Efirst_dir::LEFT)
		{
			Point temp3 = game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_LEFT);
			pc[LEFT_PLAYER].destination_calculater(temp3.get_x(), temp3.get_y(), game_ball.get_direction());
		}
	}



}

void Game::game_initializer() /* over here we update all of the relveant things that the game requiers */
{
		game_tetris.set_tetris_screen(&game_screen);
		game_keyboard->set_tetris(&game_tetris);  /*  <<<<===*/
		//game_keyboard->keyboard_register(&left_player);
		//game_keyboard->keyboard_register(&right_player);
		game_screen.player_register(left_player);
		game_screen.player_register(right_player);
		game_keyboard->set_menu(game_menu->get_mode());
//		game_menu->message_printer(MESSAGE_ONE);    /*  when the game starts first of all it prints the main menu*/
	//	game_menu->message_printer(MESSAGE_EIGHT);
		//game_menu->message_printer(MESSAGE_NINE);
		game_menu->print_main_menu_display(Menu::MAIN_DISPLAY);
		game_screen.set_left_lim(&game_ball, START_LEFT_BOARD);
		game_screen.set_right_lim(&game_ball, START_RIGHT_BOARD);
}

void Game::play_game()
{

	hideConsoleCursor();
	bool first_time = false;
	bool start_over = false;
	bool should_ball_move = false;
	while (!game_menu->get_mode()->get(Game_Position::EMENU::EXIT) && !start_over && !did_some_one_lose)
	{

		should_ball_move = game_keyboard->keyboard_distributor();

		/* if the user requsted a new game but also wants the pc_level menu*/
		if (game_menu->get_mode()->get(Game_Position::EMENU::REQ_LEVEL_MENU))
		{
			
			if (game_menu->get_mode()->get_mode() == Game_Position::Emode::START_C_VS_C)
			{
				
				if (game_menu->get_mode()->get_R_if_care() == Game_Position::Ecare_pc_level::DONT_CARE)
				{
					system("cls");
					cout << "please enter a level for the left player:" << endl;
					game_menu->level_options_printer();
					game_menu->get_mode()->set(Game_Position::EMENU::REQ_LEVEL_MENU, false);
					

				}
				else  if( /*game_menu->get_mode()->get_R_if_care() == Game_Position::Ecare_pc_level::DONT_CARE &&*/ first_time==false)
				{
					system("cls");
					cout << "please enter a right for the right player:" << endl;
					game_menu->level_options_printer();
					first_time = true;
				}

			}
			else if (game_menu->get_mode()->get_mode() == Game_Position::Emode::START_H_VS_C)
			{
				system("cls");
				cout << "please enter a right for the right player:" << endl;
				game_menu->level_options_printer();
				game_menu->get_mode()->set(Game_Position::EMENU::REQ_LEVEL_MENU, false);
			}

			
			

			//game_menu->get_mode()->set(Game_Position::EMENU::REQ_LEVEL_MENU, false);
			game_menu->get_mode()->set(Game_Position::EMENU::IN_LEVEL_MENU, true);
			
		}

		 /* once the user has choosen the  a level for the computer player then we exit this menu and "fall to the next if that starts the game*/
		if (game_menu->get_mode()->get(Game_Position::EMENU::IN_LEVEL_MENU) && game_menu->get_mode()->get(Game_Position::EMENU::EXIT_LEVEL_MENU))
		{
			if (game_menu->get_mode()->get_mode() == Game_Position::Emode::START_H_VS_C)
			{
				pc[RIGHT_PLAYER].set_level((Pc_Board::Ecomputer_mode)game_menu->get_mode()->get_R_pc_level());
			}
			else if (game_menu->get_mode()->get_mode() == Game_Position::Emode::START_C_VS_C)
			{
				pc[RIGHT_PLAYER].set_level((Pc_Board::Ecomputer_mode)game_menu->get_mode()->get_R_pc_level());
				pc[LEFT_PLAYER].set_level((Pc_Board::Ecomputer_mode)game_menu->get_mode()->get_L_pc_level());

			}
			game_menu->get_mode()->set(Game_Position::EMENU::IN_LEVEL_MENU, false);
			game_menu->get_mode()->set(Game_Position::EMENU::EXIT_LEVEL_MENU, false);

		}

		/* if a new game is requested*/

		if (game_menu->get_mode()->get(Game_Position::EMENU::START_GAME) && !game_menu->get_mode()->get(Game_Position::EMENU::REQ_LEVEL_MENU)
			  && !game_menu->get_mode()->get(Game_Position::EMENU::IN_LEVEL_MENU) )
		{
			first_time = false;
			/* if we are not in a middle of a game*/
			if (!game_menu->get_mode()->get(Game_Position::EMENU::IN_GAME))
			{
				which_game();
				system("cls");

				left_player->initialize_drawer();
				right_player->initialize_drawer();
				game_menu->get_mode()->set(Game_Position::EMENU::IN_GAME, true);
			}

			/*  if we are in a middle of a game  */

			else if (game_menu->get_mode()->get(Game_Position::EMENU::IN_GAME) && game_menu->get_mode()->get(Game_Position::EMENU::IN_PAUSE))
			{

				start_over = true;
				game_menu->get_mode()->set(Game_Position::EMENU::IN_GAME, false);
				game_keyboard->zerolization();
			}
			ball_state = NEW_BALL;
			game_menu->get_mode()->set(Game_Position::EMENU::START_GAME, false);
			game_menu->get_mode()->set(Game_Position::EMENU::IN_PAUSE, false);

		}

		    
		



		/* if the user wants to return from pause to the game*/

		if (game_menu->get_mode()->get(Game_Position::EMENU::EXIT_PAUSE))
		{
			if (game_menu->get_mode()->get(Game_Position::EMENU::IN_PAUSE))
			{
				system("cls");
				left_player->initialize_drawer();
				right_player->initialize_drawer();
				game_tetris.tetris_complete_redraw();
				ball_state = OLD_BALL;
				game_menu->get_mode()->set(Game_Position::EMENU::IN_PAUSE, false);
			}
			game_menu->get_mode()->set(Game_Position::EMENU::EXIT_PAUSE, false);

		}





		/* if pause is requested*/


		if (game_menu->get_mode()->get(Game_Position::EMENU::REQ_PAUSE))
		{

			if (!game_menu->get_mode()->get(Game_Position::EMENU::IN_PAUSE))
			{
				system("cls");
				game_menu->print_main_menu_display(Menu::Edisplay_mode::PAUSE_DISPLAY);
				game_menu->get_mode()->set(Game_Position::EMENU::IN_PAUSE, true);
			}

			game_menu->get_mode()->set(Game_Position::EMENU::REQ_PAUSE, false);
		}

		/*if the user requested to show instructions  */

		if (game_menu->get_mode()->get(Game_Position::EMENU::REQ_INFO))
		{

			if (!game_menu->get_mode()->get(Game_Position::EMENU::IN_INFO))
			{

				/* here we print the info to the screen*/
				system("cls");
				cout << "In our Pong game, once a player misses the ball a copy of his board will drop" << endl;
				cout << "as in tetris game to the lowest position on his side of the screen" << endl;
				cout << "and the new position of the board will go up by one, making him one step closer"<<endl;
				cout << "to losing." << endl;
				cout << "In case dropped boards complete a full line, the entire line would disappear" << endl;
				cout << "and the board would gain back five lines." << endl;
				cout << "The player whose board reaches the position of quarter of screen - loses." << endl;
				cout << endl << "Keys:" << endl;
				cout << endl << "for the left player:" << endl;
				cout << "press 'q' or 'Q' to go up," << endl;
				cout << "press 'a' or 'A' to go down." << endl;
				cout << "press 's' or 'S' to request bomb mode." << endl;
				cout << endl << "for the right player:" << endl;
				cout << "press 'p' or 'P' to go up," << endl;
				cout << "press 'l' or 'L' to go down." << endl;
				cout << "press 'k' or 'K' to request bomb mode."<<endl;
				cout << endl;
				cout << " if the the ball hits a dead board or the screen edge while being a Bomb: " << endl;
				cout << "the entire column of dead board would be removed and the player would gain one" << endl;
				cout << "column back" << endl;
				cout << "In case the ball hits dead board or the screen edge when NOT being a Bomb: " << endl;
				cout << "it is a miss." << endl;
				cout << "In case the ball is in regular Ball state and it misses the board it's a miss." << endl;
				cout << "In case the ball is in Bomb state and it hits the board - it�s a BIG MISS." << endl;
				cout << " once bomb mode is requested then it will be in this state for 8 ball movements." << endl;
				cout << endl << "to return to the menu please press 6" << endl;

				game_menu->get_mode()->set(Game_Position::EMENU::IN_INFO, true);
			}

			game_menu->get_mode()->set(Game_Position::EMENU::REQ_INFO, false);

		}


		/*     if the user wants to return to the menu*/
		if (game_menu->get_mode()->get(Game_Position::EMENU::EXIT_INFO))
		{

			if (game_menu->get_mode()->get(Game_Position::EMENU::IN_INFO))
			{

				if (game_menu->get_mode()->get(Game_Position::EMENU::IN_PAUSE))
				{
					system("cls");
					game_menu->print_main_menu_display(Menu::Edisplay_mode::PAUSE_DISPLAY);
				}
				else /* we are not in pause*/
				{
					system("cls");
					game_menu->print_main_menu_display(Menu::Edisplay_mode::MAIN_DISPLAY);
				}

				game_menu->get_mode()->set(Game_Position::EMENU::IN_INFO, false);
			}

			game_menu->get_mode()->set(Game_Position::EMENU::EXIT_INFO, false);
		}


		if (should_ball_move && !game_menu->get_mode()->get(Game_Position::EMENU::IN_LEVEL_MENU))
		{
			if (ball_state == NEW_BALL)
			{
				game_ball.initial_position();
				game_ball.Complete_matrix_drawer('O');
				left_player->move();
				right_player->move();
				ball_state = OLD_BALL;
			}
			else if (ball_state == OLD_BALL)
			{
				left_player->move();
				right_player->move();

			}
			current_type = game_ball.get_ball_state()->get_my_type();
			game_ball.set_ball_state(Ball_Interface::Eball_state::REGULAR);
			game_ball.get_ball_state()->set_x_ball_coord(game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_LEFT).get_x());
			game_ball.get_ball_state()->counter_successor();
			game_ball.set_ball_state(Ball_Interface::Eball_state::BOMB);
			game_ball.get_ball_state()->set_x_ball_coord(game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_LEFT).get_x());
			game_ball.get_ball_state()->set_right_limit(right_player->get_x_coord());
			game_ball.get_ball_state()->set_left_limit(left_player->get_x_coord());
			game_ball.set_ball_state(current_type);
			if (game_ball.get_ball_state()->get_my_type() != Ball_Interface::Eball_state::REGULAR)
			{
				game_ball.get_ball_state()->counter_successor();
			}
			game_ball.change_state();

			game_ball.get_ball_state()->print_in_color();
			game_ball.move();
			set_text_color(15);
			Pos_l = left_player->check_ball_position(game_ball, game_ball.get_left_edge_point(), LEFT);   /* here we check if the ball missed or hit one of the boards*/
			Pos_r = right_player->check_ball_position(game_ball, game_ball.get_right_edge_point(), RIGHT);
			/* these two switch checks once for the right player and once for the left player if the ball hit a board or not
			and  updated the balls coordinated as well as the coordinates of the board if needed.
			in addition if the ball missed the board we also applay the tetris function in the switch*/
			switch (Pos_l)
			{

			case Board::ball_position::CORNER_HIT:
				game_ball.set_dir_y(game_ball.get_dir_y() * -1);
			case Board::ball_position::CENTER_HIT:
				game_ball.set_dir_x(game_ball.get_dir_x() * -1);

				if (game_ball.get_ball_state()->get_my_type() == Ball_Interface::Eball_state::GOING_TO_BE_A_BOMB)
				{
					game_ball.get_ball_state()->set_counter(0);
					game_ball.get_ball_state()->set_activation(false);
					game_ball.set_ball_state(Ball_Interface::Eball_state::REGULAR);
					game_ball.get_ball_state()->set_activation(false);
				}///////////////////////////////////////  hit the board with becoming a bomb
				else if (game_ball.get_ball_state()->get_my_type() == Ball_Interface::Eball_state::BOMB)
				{
					game_screen.set_left_lim(&game_ball, 3);
					game_tetris.set_fallen_board(*left_player);
					game_tetris.move(Tetris::DIRECTION::LEFT);
					left_player->board_eraser();
					left_player->update_location(3);
					if (left_player->get_x_coord() >= LEFT_LOSE)
					{
						did_some_one_lose = true;
						game_keyboard->zerolization();
						game_keyboard->set_should_ball_move(false);
						game_keyboard->set_logi_players_number(0);
					}
					else
					{
						if (game_tetris.check_and_maybe_delete_column(Tetris::DIRECTION::LEFT, left_player->get_x_coord()))
						{
							left_player->board_eraser();
							left_player->update_location(5 * (int)Tetris::DIRECTION::LEFT);
							left_player->initialize_drawer();
							game_screen.set_left_lim(&game_ball, -6);
						}

						left_player->initialize_drawer();
					}
					game_ball.Eraser();
					game_ball.initial_position();
				}
				if (game_menu->get_mode()->get_mode() != Game_Position::Emode::START_H_VS_H)
				{
					Point temp = game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_RIGHT);
					pc[RIGHT_PLAYER].destination_calculater(temp.get_x(), temp.get_y(), game_ball.get_direction());

				}
				break;
			case Board::ball_position::AFTER_BOARD:                                                  /*         Note- when we reach here wheather we are a bomb or going to be a bomb
																												we want to know if we hit a dead board or reached the limit of the screen
																												if  we are in one of those cases and we are a bomb then we want to only
																												do the  second if , but if we are in of those cases and we are going to
																												to be a bomb then we want to treat it like a regular ball miss
																												and that is why there is no break but if we are going to be a bomb
																												and did not hit a dead board or reach the screen limit then we
																												dont want it to count like a miss and that is why there is a break in this case*/
				int res;
				if (game_ball.get_left_edge_point().get_x() >= Ball::Escreen_parameters::MIN_X ) ///////////////////////////////// changed 6/1
				{
					res = check_hit_dead_board();
				}
				else
				{
					res = Ball::Escreen_parameters::MIN_X-1;
				}
				if (game_ball.get_ball_state()->get_my_type() == Ball_Interface::Eball_state::BOMB)
				{
					if (res != -1)
					{
						game_screen.forget_column(res);
						game_screen.erase_column(res);
						game_screen.set_left_lim(&game_ball, -1);
						game_screen.forget_column(left_player->get_x_coord() - 1);
						game_screen.erase_column(left_player->get_x_coord() - 1);
						left_player->board_eraser();
						left_player->update_location(-1);
						left_player->initialize_drawer();
						game_ball.Eraser();
						game_ball.initial_position();
					}

					break;
				}
				else if (game_ball.get_ball_state()->get_my_type() == Ball_Interface::Eball_state::GOING_TO_BE_A_BOMB)
				{
					if (res == -1)
					{
						break;
					}
				}

			case Board::ball_position::MISSED:
				game_screen.set_left_lim(&game_ball, 1);
				game_tetris.set_fallen_board(*left_player);
				game_tetris.move(Tetris::DIRECTION::LEFT);
				left_player->board_eraser();
				left_player->update_location(1);
				if (left_player->get_x_coord() == LEFT_LOSE)
				{
					did_some_one_lose = true;
					game_keyboard->zerolization();
					game_keyboard->set_should_ball_move(false);
					game_keyboard->set_logi_players_number(0);
				}
				else
				{
					left_player->initialize_drawer();
					if (game_tetris.check_and_maybe_delete_column(Tetris::DIRECTION::LEFT, left_player->get_x_coord()))
					{

						left_player->board_eraser();
						left_player->update_location(5 * (int)Tetris::DIRECTION::LEFT);
						left_player->initialize_drawer();
						game_screen.set_left_lim(&game_ball, -6);
						game_ball.initial_position();
					}
				}
				game_ball.Eraser();
				game_ball.set_balls_initial_coords();
				if (game_menu->get_mode()->get_mode() != Game_Position::Emode::START_H_VS_H)
				{
					Point temp = game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_RIGHT);
					pc[LEFT_PLAYER].destination_calculater(temp.get_x(), temp.get_y(), game_ball.get_direction());

				}
				break;

			case Board::ball_position::AWAY:
				break;

			}

			switch (Pos_r)
			{
			case Board::ball_position::CORNER_HIT:
				game_ball.set_dir_y(game_ball.get_dir_y() * -1);
			case Board::ball_position::CENTER_HIT:
				game_ball.set_dir_x(game_ball.get_dir_x() * -1);
				if (game_ball.get_ball_state()->get_my_type() == Ball_Interface::Eball_state::GOING_TO_BE_A_BOMB)
				{
					game_ball.get_ball_state()->set_counter(0);
					game_ball.get_ball_state()->set_activation(false);
					game_ball.set_ball_state(Ball_Interface::Eball_state::REGULAR);
					game_ball.get_ball_state()->set_activation(false);
				}///////////////////////////////////////  hit the board with becoming a bomb
				else if (game_ball.get_ball_state()->get_my_type() == Ball_Interface::Eball_state::BOMB)
				{
					game_screen.set_right_lim(&game_ball, -3);
					game_tetris.set_fallen_board(*right_player);
					game_tetris.move(Tetris::DIRECTION::RIGHT);
					right_player->board_eraser();
					right_player->update_location(-3);

					if (right_player->get_x_coord() <= RIGHT_LOSE)
					{
						did_some_one_lose = true;
						game_keyboard->zerolization();
						game_keyboard->set_should_ball_move(false);
						game_keyboard->set_logi_players_number(0);
					}
					else
					{
						if (game_tetris.check_and_maybe_delete_column(Tetris::DIRECTION::RIGHT, right_player->get_x_coord()))
						{
							right_player->board_eraser();
							right_player->update_location(5 * (int)Tetris::DIRECTION::RIGHT);
							right_player->initialize_drawer();
							game_screen.set_left_lim(&game_ball, 6);
							game_ball.initial_position();
						}
						right_player->initialize_drawer();
					}
				}
				if (game_menu->get_mode()->get_mode() == Game_Position::Emode::START_C_VS_C)
				{
					Point temp = game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_RIGHT);
					pc[LEFT_PLAYER].destination_calculater(temp.get_x(), temp.get_y(), game_ball.get_direction());

				}
				break;
			case Board::ball_position::AFTER_BOARD:                                                  /*         Note- when we reach here wheather we are a bomb or going to be a bomb
																									 we want to know if we hit a dead board or reached the limit of the screen
																									 if  we are in one of those cases and we are a bomb then we want to only
																									 do the  second if , but if we are in of those cases and we are going to
																									 to be a bomb then we want to treat it like a regular ball miss
																									 and that is why there is no break but if we are going to be a bomb
																									 and did not hit a dead board or reach the screen limit then we
																									 dont want it to count like a miss and that is why there is a break in this case*/
				int res;
				if (game_ball.get_right_edge_point().get_x() > Ball::Escreen_parameters::MAX_X) ///////////////////////////////// changed 6/1
				{
					res = check_hit_dead_board();
				}
				else
				{
					res = Ball::Escreen_parameters::MAX_X;
				}
				if (game_ball.get_ball_state()->get_my_type() == Ball_Interface::Eball_state::BOMB)
				{
					if (res != -1)
					{
						game_screen.forget_column(res);
						game_screen.erase_column(res);
						game_screen.set_right_lim(&game_ball, 1);
						game_screen.forget_column(right_player->get_x_coord() + 1);
						game_screen.erase_column(right_player->get_x_coord() + 1);
						right_player->board_eraser();
						right_player->update_location(-1);
						right_player->initialize_drawer();
						game_ball.Eraser();
						game_ball.initial_position();
					}

					break;
				}
				else if (game_ball.get_ball_state()->get_my_type() == Ball_Interface::Eball_state::GOING_TO_BE_A_BOMB)
				{
					if (res == -1)
					{
						break;
					}
				}

			case Board::ball_position::MISSED:

				game_screen.set_right_lim(&game_ball, -1);
				game_tetris.set_fallen_board(*right_player);
				game_tetris.move(Tetris::DIRECTION::RIGHT);
				right_player->board_eraser();
				right_player->update_location(-1);
				if (right_player->get_x_coord() == RIGHT_LOSE)
				{
					did_some_one_lose = true;
					game_keyboard->zerolization();
					game_keyboard->set_should_ball_move(false);
					game_keyboard->set_logi_players_number(0);
				}

				else
				{
					right_player->initialize_drawer();
					if (game_tetris.check_and_maybe_delete_column(Tetris::DIRECTION::RIGHT, right_player->get_x_coord()))
					{

						right_player->board_eraser();
						right_player->update_location(5 * (int)Tetris::DIRECTION::RIGHT);
						right_player->initialize_drawer();
						game_screen.set_right_lim(&game_ball, 6);
						game_ball.initial_position();
					}
				}
				game_ball.Eraser();
				game_ball.set_balls_initial_coords();
				if (game_menu->get_mode()->get_mode() == Game_Position::Emode::START_C_VS_C)
				{
					Point temp = game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_RIGHT);
					pc[RIGHT_PLAYER].destination_calculater(temp.get_x(), temp.get_y(), game_ball.get_direction());

				}
				break;
			case Board::ball_position::AWAY:
				break;


			}

			Sleep(100);

		}



	}

}
	

/* this function checks if the ball hit a dead board and if it did then clean the entire column and updates the boards location as requested in the
game instructions*/

	int Game::check_hit_dead_board()
	{
		int res = -1;
		int adder_y;
		int adder_x;
		int temp_x_coord;
		int temp_y_coord;
		int temp_x_coord1;
		int temp_y_coord1;
		Ball::Eball_direction temp_dir = game_ball.get_direction();
		if (temp_dir == Ball::Eball_direction::LU)
		{
			adder_x = -1;
			adder_y = -1;
			temp_x_coord = game_ball.get_left_edge_point().get_x();
			temp_y_coord = game_ball.get_left_edge_point().get_y();
			temp_x_coord1 = game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_LEFT).get_x();
			temp_y_coord1 = game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_LEFT).get_y();
		}
		if (temp_dir == Ball::Eball_direction::RU)
		{
			adder_x = 1;
			adder_y = -1;
			temp_x_coord = game_ball.get_right_edge_point().get_x();
			temp_y_coord = game_ball.get_right_edge_point().get_y();
			temp_x_coord1 = game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_RIGHT).get_x();
			temp_y_coord1 = game_ball.get_upper_corner_point(Ball::Eball_corner::UPPER_RIGHT).get_y();
		}
		if (temp_dir == Ball::Eball_direction::LD)
		{
			adder_x = -1;
			adder_y = 1;
			temp_x_coord = game_ball.get_left_edge_point().get_x();
			temp_y_coord = game_ball.get_left_edge_point().get_y();
			temp_x_coord1 = game_ball.get_lower_corner_point(Ball::Eball_corner::UPPER_LEFT).get_x();
			temp_y_coord1 = game_ball.get_lower_corner_point(Ball::Eball_corner::UPPER_LEFT).get_y();
		}
		if (temp_dir == Ball::Eball_direction::RD)
		{
			adder_x = 1;
			adder_y = 1;
			temp_x_coord = game_ball.get_right_edge_point().get_x();
			temp_y_coord = game_ball.get_right_edge_point().get_y();
			temp_x_coord1 = game_ball.get_lower_corner_point(Ball::Eball_corner::UPPER_RIGHT).get_x();
			temp_y_coord1 = game_ball.get_lower_corner_point(Ball::Eball_corner::UPPER_RIGHT).get_y();
		}

		if (!game_screen.is_empty(temp_x_coord + adder_x, temp_y_coord))
		{
			game_screen.forget_column(temp_x_coord + adder_x);
			game_screen.erase_column(temp_x_coord + adder_x);
			res = temp_x_coord + adder_x;
		}

		else if (!game_screen.is_empty(temp_x_coord1 + adder_x, temp_y_coord1))
		{
			game_screen.forget_column(temp_x_coord1 + adder_x);
			game_screen.erase_column(temp_x_coord1 + adder_x);
			res = temp_x_coord1 + adder_x;
		}
		else if (!game_screen.is_empty(temp_x_coord1, temp_y_coord1 + adder_y))
		{
			game_screen.forget_column(temp_x_coord1);
			game_screen.erase_column(temp_x_coord1);
			res = temp_x_coord1;
		}
		else if (!game_screen.is_empty(temp_x_coord + adder_x, temp_y_coord + adder_y))
		{
			game_screen.forget_column(temp_x_coord + adder_x);
			game_screen.erase_column(temp_x_coord + adder_x);
			res = temp_x_coord + adder_x;
		}
		else if (!game_screen.is_empty(temp_x_coord1 + adder_x, temp_y_coord1 + adder_y))
		{
			game_screen.forget_column(temp_x_coord1 + adder_x);
			game_screen.erase_column(temp_x_coord1 + adder_x);
			res = temp_x_coord1 + adder_x;
		}
		return res;
	}













	/*

		while (game_menu->get_should_start_over() == false && game_keyboard->get_termination_mode()==false && did_some_one_lose==false) //true)
		{
			if (game_keyboard->keyboard_distributor() ) // here the keyboard checks what has been pressed and return if the ball should move
			{
				if (starting_new_game) // if we are in a new game then the ball will be in the middle of the screen
				{
					game_ball.initial_position();
					game_ball.Complete_matrix_drawer('O');
					starting_new_game = false;
				}
				 // if we are in a middle of game then the ball will just keep on moving
				should_print_start_up_menu = false;
				game_ball.move();
				Pos_l = left_player.check_ball_position(game_ball, game_ball.get_left_edge_point(), LEFT);   // here we check if the ball missed or hit one of the boards
				Pos_r = right_player.check_ball_position(game_ball, game_ball.get_right_edge_point(), RIGHT);

			}


			// these two switch checks once for the right player and once for the left player if the ball hit a board or not
			//    and  updated the balls coordinated as well as the coordinates of the board if needed.
			//	in addition if the ball missed the board we also applay the tetris function in the switch
				switch (Pos_l)
				{

				case Board::ball_position::CENTER_HIT: 
					game_ball.set_dir_x(game_ball.get_dir_x() * -1);
					break;
				
				case Board::ball_position::CORNER_HIT:
					game_ball.set_dir_x(game_ball.get_dir_x() * -1);
					game_ball.set_dir_y(game_ball.get_dir_y() * -1);
					break;
				case Board::ball_position::MISSED:
					game_screen.set_left_lim(&game_ball, 1);
					game_tetris.set_fallen_board(left_player);
					game_tetris.move(Tetris::DIRECTION::LEFT);
					left_player.board_eraser();
					left_player.update_location(1);
					if (left_player.get_x_coord() == LEFT_LOSE)
					{
						did_some_one_lose = true;
						game_keyboard->set_should_ball_move(false);
						game_keyboard->set_logi_players_number(0);
					}
					else
					{
						left_player.initialize_drawer();
						if (game_tetris.check_and_maybe_delete_column(Tetris::DIRECTION::LEFT, left_player.get_x_coord()))
						{

							left_player.board_eraser();
							left_player.update_location(5 * (int)Tetris::DIRECTION::LEFT);
							left_player.initialize_drawer();
							game_screen.set_left_lim(&game_ball, -6);
							game_ball.initial_position(); ///////////////////////////////////////////////////
						}
					}
					break;
				case Board::ball_position::AWAY:
					break;

				}

				switch (Pos_r)
				{

				case Board::ball_position::CENTER_HIT:
					game_ball.set_dir_x(game_ball.get_dir_x() * -1);
					break;

				case Board::ball_position::CORNER_HIT:
					game_ball.set_dir_x(game_ball.get_dir_x() * -1);
					game_ball.set_dir_y(game_ball.get_dir_y() * -1);
					break;
				case Board::ball_position::MISSED:
					game_screen.set_right_lim(&game_ball, -1);
					game_tetris.set_fallen_board(right_player);
					game_tetris.move(Tetris::DIRECTION::RIGHT);
					right_player.board_eraser();
					right_player.update_location(-1);
					if (right_player.get_x_coord() == RIGHT_LOSE)
					{
						did_some_one_lose = true;
						game_keyboard->set_should_ball_move(false);
						game_keyboard->set_logi_players_number(0);
					}

					else
					{
						right_player.initialize_drawer();
						if (game_tetris.check_and_maybe_delete_column(Tetris::DIRECTION::RIGHT, right_player.get_x_coord()))
						{

							right_player.board_eraser();
							right_player.update_location(5 * (int)Tetris::DIRECTION::RIGHT);
							right_player.initialize_drawer();
							game_screen.set_right_lim(&game_ball, 6);
							game_ball.initial_position();
						}
					}
					break;
				case Board::ball_position::AWAY:
					break;


				}

				Sleep(100);

			}

		}

	*/
	

