#ifndef GAME_OBJECTS_H
#define GAME_OBJECTS_H

#include "Game.h"
#include "Menu.h"

/*this is the type of objects that will be in the our stack*/
typedef struct game_objects
{
	Game our_game;
	game_objects * next=nullptr;
} Game_objects;

#endif // !GAME_OBJECTS_H