#ifndef  KEYBOARD_H
#define KEYBOARD_H

#include "Ball.h"
#include "Board.h"
#include <conio.h>
#include "Menu.h"
#include "Tetris.h"
#include "Kb_Listener.h"
#define _CRT_SECURE_NO_WARNINGS
#include "Game_Position.h"
class KeyBoard {
public:
    enum { NO, YES, ESCAPE = 27, NUM_OPTIONS = 4 };

private:
	enum{ MAX_REGISTERD_LISTENERS=3};
	enum { FIRST_INDEX=0, NUM_OF_CHARS=26};
	Kb_Listener* keyboard_setter[NUM_OF_CHARS] = { 0 };
	Game_Position* Game_pos;
	Kb_Listener*  registerd_listeners[MAX_REGISTERD_LISTENERS]{};
	Tetris* game_tetris;
	bool should_ball_move = false;
	int start_game = NO;
	int logi = 0;
	int pause = NO;
	bool terminate = false; /* this will tell us if option nine was pressed*/
	char to_lower(char ch) 
	{
		if (ch >= 'A'&& ch <= 'Z')
		{
			ch = ch - 'A' + 'a';
		}
		return ch;

	}

	int get_index(char ch)
	{
		return to_lower(ch) - 'a';
	}

public :
	
	void zerolization();
	void keyboard_register(Kb_Listener* new_listener);

	bool keyboard_distributor(); /* infroms the relveant boards that they need to move*/

	void set_menu(Game_Position* game_pos)
	{
		this->Game_pos = game_pos;
	}

	void set_tetris(Tetris* tetris_game)
	{
		game_tetris = tetris_game;
	}
	
	int get_num_of_registerd_players() const
	{
		 return logi;
	}

	const Kb_Listener* get_registerd_board_at(int index) const
	{
		return registerd_listeners[index];
	}

	bool get_termination_mode()
	{
		return terminate;
	}


	void set_should_ball_move(bool decision)
	{
		should_ball_move = decision;
	}

	void set_logi_players_number(int number)
	{
		logi = number;
	}
};


#endif // ! KEYBOARD_H



