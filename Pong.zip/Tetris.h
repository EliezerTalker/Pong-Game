#ifndef TETRIS_H
#define TETRIS_H


#include "Board.h"
#include "Screen.h"

class  Tetris {
public:
	enum class DIRECTION { LEFT = -1, RIGHT = 1 };
private:

	Screen *game_screen;
	Board* fallen_board;
	int absolute(int x)
	{
		if (x < 0)
			x *= (-1);
		return x;
	}

public:

	Tetris() 
	{
		fallen_board = new Board( 0,0,0 );
	
	}

	void set_fallen_board(const Board& original_board)
	{
		*fallen_board= original_board;
	}

	void move(Tetris::DIRECTION dir);

	bool check_and_maybe_delete_column(Tetris::DIRECTION dir, int curr_location); /*checks if the there is a full column of boards*/


	void tetris_complete_redraw()  /* draws all of the fallen boards*/
	{

		game_screen->complete_screen_drawer('|');
	}


	void set_tetris_screen(Screen* screen_to_set)
	{
		game_screen = screen_to_set;
	}


	Screen* get_tetris_screen()
	{
		return game_screen;
	}

};


#endif // ! TETRIS_H







