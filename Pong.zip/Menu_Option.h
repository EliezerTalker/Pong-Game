#ifndef  MENU_OPTION_H
#define  MENU_OPTION_H

#include <iostream>
#include <string.h>
#include "utils.h"
using namespace std;

class Menu_Option
{
	enum{ NOT_PRINTED, PRINTED};
	char* Option_Message;
	int Starter_x;
	int Starter_y;
	int Ender_x;
	int Ender_y;
	int message_size;
	int am_i_printed= NOT_PRINTED;
public:
	Menu_Option(){}

	Menu_Option(const char* message, int Strarter_x, int Strarter_y); 
	Menu_Option(const Menu_Option& other) = delete;         /* we delete these ctor because we dont use them*/
	void operator== (const Menu_Option& other) = delete;
	~Menu_Option() {
		delete[] Option_Message;
	}

	void Set_starting_point(int coord_x, int coord_y);

	int get_Strater_x() const
	{
		return Starter_x;
	}

	int get_Strater_y()  const
	{
		return Starter_y;
	}

	int get_Ender_x() const
	{
		return Ender_x;
	}

	int get_Ender_y() const
	{
		return Ender_y;
	}

	void message_printer()
	{
		gotoxy(this->Starter_x, this->Starter_y);
		cout << Option_Message << endl;
		am_i_printed = PRINTED;
	}

	void messages_print_deleter();

	void message_setter(const char* message); 

};













#endif // ! Menu_Option
