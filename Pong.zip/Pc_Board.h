#ifndef PC_BOARD_H
#define PC_BOARD_H
#include "Board.h"
#include <stdio.h>      /* printf, NULL */
#include <stdlib.h>     /* srand, rand */
#include <ctime>





 /* change player to human player*/
class Pc_Board : public Board
{
public:
	enum class Ecomputer_mode { NOVICE, GOOD, BEST };
private:
	int final_destination = 12;
	Ecomputer_mode chosen_level;
	
	

	 


public:


	Pc_Board(int Top_y, int Bottom_y, int Board_location) :Board(Top_y, Bottom_y, Board_location) {}
	
	void destination_calculater(int x_coord, int y_coord, Ball::Eball_direction direction);

	void move();

	void set_level(Ecomputer_mode level)
	{
		chosen_level = level;
	}
	Ecomputer_mode get_level()
	{
		return chosen_level;
	}


};




#endif // !PC_BOARD_H
