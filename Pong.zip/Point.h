#ifndef  POINT_H
#define POINT_H

#define _CRT_SECURE_NO_WARNINGS

#include "utils.h"

class Point {
	
	int x;
	int y;
	char ch;

public:

	Point(int x , int y,char ch) : x(x), y(y), ch(ch) {}

	 void set_x(int x)
	{
		this->x = x;
	}
	void set_y(int y)
	{
		this->y = y;
	}

	 void set(int x, int y)
	 {
		 set_x(x);
		 set_y(y);
	 }


	 int get_x() const { return x; }
	 int get_y() const { return y; }
	 char get_char() const { return ch; }

};








#endif // ! POINT_H
