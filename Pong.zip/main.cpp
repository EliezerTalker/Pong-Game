#include "Game_manager.h"
#define _CRT_SECURE_NO_WARNINGS


/* over here we we make an object of the call Game_manager and apply his function which runs the game and handles the memory*/
void main()
{
	srand(time(NULL));
	Game_manager pong;
	pong.manage_game();
}


	


